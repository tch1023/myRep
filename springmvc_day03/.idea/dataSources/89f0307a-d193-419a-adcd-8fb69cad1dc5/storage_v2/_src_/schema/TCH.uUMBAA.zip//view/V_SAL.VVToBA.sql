create view V_SAL as
select salary from s_emp
/

